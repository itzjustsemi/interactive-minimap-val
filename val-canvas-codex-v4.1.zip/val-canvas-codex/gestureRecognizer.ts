export interface Point {
    x: number;
    y: number;
}

interface StrokePoint extends Point {
    id: number;
}

interface Template {
    name: string;
    points: StrokePoint[];
    strokeCount: number;
}

export class GestureRecognizer {
    private templates: Template[] = [];
    private readonly NUM_POINTS = 32;
    private threshold = 0.4; // Lowered to accommodate realistic human variations; adjustable via setThreshold()
    private enforceStrokeCount = true; // When true, only compares against templates with a matching pen-lift count

    constructor() {
        this.initializeDefaultTemplates();
    }

    /** Update the base match threshold at runtime (e.g. from the settings slider). */
    public setThreshold(threshold: number) {
        this.threshold = threshold;
    }

    public getThreshold(): number {
        return this.threshold;
    }

    /** Toggle whether recognition is restricted to templates with the same number of strokes as the drawn gesture. */
    public setEnforceStrokeCount(enabled: boolean) {
        this.enforceStrokeCount = enabled;
    }

    public getEnforceStrokeCount(): boolean {
        return this.enforceStrokeCount;
    }

    private initializeDefaultTemplates() {
        // 'X' - Two intersecting strokes with dense intermediate points to improve matching
        // All 4 stroke-order combinations to handle any drawing direction
        const diagTLBR = [
            { x: 0, y: 0 }, { x: 0.25, y: 0.25 }, { x: 0.5, y: 0.5 }, { x: 0.75, y: 0.75 }, { x: 1, y: 1 }
        ];
        const diagBLTR = [
            { x: 0, y: 1 }, { x: 0.25, y: 0.75 }, { x: 0.5, y: 0.5 }, { x: 0.75, y: 0.25 }, { x: 1, y: 0 }
        ];
        const diagTRBL = [
            { x: 1, y: 0 }, { x: 0.75, y: 0.25 }, { x: 0.5, y: 0.5 }, { x: 0.25, y: 0.75 }, { x: 0, y: 1 }
        ];
        const diagBRTL = [
            { x: 1, y: 1 }, { x: 0.75, y: 0.75 }, { x: 0.5, y: 0.5 }, { x: 0.25, y: 0.25 }, { x: 0, y: 0 }
        ];
        this.addTemplate("X", [diagTLBR, diagTRBL]);
        this.addTemplate("X", [diagTLBR, diagBLTR]);
        this.addTemplate("X", [diagBRTL, diagTRBL]);
        this.addTemplate("X", [diagBRTL, diagBLTR]);
        this.addTemplate("X", [diagTRBL, diagTLBR]);
        this.addTemplate("X", [diagBLTR, diagTLBR]);
        this.addTemplate("X", [diagTRBL, diagBRTL]);
        this.addTemplate("X", [diagBLTR, diagBRTL]);

        // 'Checkmark' - Single stroke
        this.addTemplate("Checkmark", [
            [{ x: 0, y: 0.5 }, { x: 0.15, y: 0.65 }, { x: 0.3, y: 1 }, { x: 0.65, y: 0.5 }, { x: 1, y: 0 }]
        ]);

        // 'Circle' - Single stroke (approximated with points)
        const circleStrokes: Point[][] = [[]];
        for (let i = 0; i <= 32; i++) {
            const angle = (i / 32) * Math.PI * 2;
            circleStrokes[0].push({
                x: 0.5 + 0.5 * Math.cos(angle),
                y: 0.5 + 0.5 * Math.sin(angle)
            });
        }
        // Also add a counter-clockwise variant
        const circleStrokesCCW: Point[][] = [[]];
        for (let i = 0; i <= 32; i++) {
            const angle = -(i / 32) * Math.PI * 2;
            circleStrokesCCW[0].push({
                x: 0.5 + 0.5 * Math.cos(angle),
                y: 0.5 + 0.5 * Math.sin(angle)
            });
        }
        this.addTemplate("Circle", circleStrokes);
        this.addTemplate("Circle", circleStrokesCCW);

        // 'Star' - Single stroke 5-point star
        this.addTemplate("Star", [
            [
                { x: 0.5, y: 0 },
                { x: 0.8, y: 1 },
                { x: 0, y: 0.38 },
                { x: 1, y: 0.38 },
                { x: 0.2, y: 1 },
                { x: 0.5, y: 0 }
            ]
        ]);

        // '#' - Four strokes: left vertical, right vertical, top horizontal, bottom horizontal
        // Stroke order variations to allow flexible drawing
        const leftV = [{ x: 0.25, y: 0 }, { x: 0.25, y: 1 }];
        const rightV = [{ x: 0.75, y: 0 }, { x: 0.75, y: 1 }];
        const topH = [{ x: 0, y: 0.33 }, { x: 1, y: 0.33 }];
        const botH = [{ x: 0, y: 0.67 }, { x: 1, y: 0.67 }];
        this.addTemplate("#", [leftV, rightV, topH, botH]);
        this.addTemplate("#", [topH, botH, leftV, rightV]);
        this.addTemplate("#", [leftV, rightV, botH, topH]);
        this.addTemplate("#", [rightV, leftV, topH, botH]);

        // 'DoubleSlash' - alternate for '#' (2 parallel, non-crossing diagonal strokes), same event type as '#'.
        // Replaces the earlier 'CircleSlash' design, which was scoring too close to 'X' at higher
        // sensitivities. Two parallel strokes (rather than a circle+slash or crossing lines) sit much
        // further from X's crossing-diagonal shape in point-cloud space. Built directly from an actual
        // captured user gesture, same approach as before - raw pixel coordinates, normalize() rescales
        // automatically regardless of coordinate space.
        const slashStrokeA: Point[] = [
            { x: 558.33, y: 597.89 }, { x: 557.41, y: 597.89 }, { x: 557.41, y: 598.81 }, { x: 556.49, y: 599.74 },
            { x: 555.57, y: 600.66 }, { x: 554.65, y: 601.58 }, { x: 553.73, y: 603.42 }, { x: 551.89, y: 605.26 },
            { x: 550.97, y: 607.10 }, { x: 550.05, y: 608.94 }, { x: 548.21, y: 610.78 }, { x: 546.37, y: 613.54 },
            { x: 544.53, y: 615.38 }, { x: 543.61, y: 617.22 }, { x: 541.77, y: 619.06 }, { x: 540.85, y: 621.82 },
            { x: 539.01, y: 623.66 }, { x: 538.09, y: 625.50 }, { x: 536.25, y: 626.42 }, { x: 536.25, y: 628.26 },
            { x: 535.33, y: 629.18 }, { x: 534.41, y: 630.10 }, { x: 534.41, y: 631.02 }, { x: 533.49, y: 631.94 },
            { x: 533.49, y: 632.86 }, { x: 534.41, y: 632.86 }, { x: 535.33, y: 631.94 }
        ];
        const slashStrokeB: Point[] = [
            { x: 571.21, y: 606.18 }, { x: 570.29, y: 607.10 }, { x: 569.37, y: 608.02 }, { x: 568.45, y: 608.94 },
            { x: 567.53, y: 609.86 }, { x: 565.69, y: 610.78 }, { x: 564.77, y: 612.62 }, { x: 562.93, y: 613.54 },
            { x: 561.09, y: 615.38 }, { x: 559.25, y: 616.30 }, { x: 557.41, y: 618.14 }, { x: 555.57, y: 619.98 },
            { x: 553.73, y: 621.82 }, { x: 551.89, y: 622.74 }, { x: 550.05, y: 624.58 }, { x: 548.21, y: 626.42 },
            { x: 547.29, y: 627.34 }, { x: 545.45, y: 629.18 }, { x: 544.53, y: 631.02 }, { x: 542.69, y: 631.94 },
            { x: 541.77, y: 632.86 }, { x: 541.77, y: 633.78 }, { x: 540.85, y: 634.70 }, { x: 540.85, y: 635.62 },
            { x: 540.85, y: 636.54 }, { x: 541.77, y: 636.54 }, { x: 542.69, y: 636.54 }
        ];
        // Mirror both strokes horizontally around their shared center to cover the opposite diagonal
        // direction too, without needing a second manual capture.
        const mirrorStrokesX = (strokes: Point[][]): Point[][] => {
            const allX = strokes.flat().map(p => p.x);
            const centerX = (Math.min(...allX) + Math.max(...allX)) / 2;
            return strokes.map(stroke => stroke.map(p => ({ x: 2 * centerX - p.x, y: p.y })));
        };
        const [mirroredSlashA, mirroredSlashB] = mirrorStrokesX([slashStrokeA, slashStrokeB]);

        this.addTemplate("DoubleSlash", [slashStrokeA, slashStrokeB]);
        this.addTemplate("DoubleSlash", [slashStrokeB, slashStrokeA]);
        this.addTemplate("DoubleSlash", [mirroredSlashA, mirroredSlashB]);
        this.addTemplate("DoubleSlash", [mirroredSlashB, mirroredSlashA]);


        // '!' - Exclamation mark for 'util' (line + dot)
        this.addTemplate("!", [
            [{ x: 0.5, y: 0 }, { x: 0.5, y: 0.7 }],
            [{ x: 0.5, y: 0.9 }, { x: 0.5, y: 1 }]
        ]);
    }

    public addTemplate(name: string, strokes: Point[][]) {
        const points = this.normalize(strokes);
        if (points.length > 0) {
            this.templates.push({ name, points, strokeCount: strokes.length });
        }
    }

    public recognize(strokes: Point[][]): { gesture: string, score: number, centroid: Point } | null {
        if (!strokes || strokes.length === 0 || strokes[0].length === 0) return null;

        // Calculate the raw centroid before normalization so caller knows where the gesture was drawn
        const rawPoints: Point[] = [];
        strokes.forEach(stroke => rawPoints.push(...stroke));
        const centroid = this.calculateCentroid(rawPoints);

        const points = this.normalize(strokes);
        if (points.length === 0) return null;

        let candidates = this.templates;
        if (this.enforceStrokeCount) {
            const inputStrokeCount = strokes.length;
            const strokeCountMatches = this.templates.filter(t => t.strokeCount === inputStrokeCount);
            // Fall back to comparing against everything if nothing shares this stroke count,
            // rather than silently failing to recognize anything at all.
            candidates = strokeCountMatches.length > 0 ? strokeCountMatches : this.templates;
        }

        // TEMP DEBUG: capture the exact raw strokes so we can build a template from real motion instead of guessing.
        console.log('[GestureRecognizer] RAW strokes (copy this for template building):', JSON.stringify(strokes));

        let bestDistance = Infinity;
        let bestGesture = "";
        const allResults: { name: string, distance: number }[] = [];

        for (const template of candidates) {
            const d = this.greedyCloudMatch(points, template.points);
            allResults.push({ name: template.name, distance: d });
            if (d < bestDistance) {
                bestDistance = d;
                bestGesture = template.name;
            }
        }

        // TEMP DEBUG: remove once gesture confusion is sorted out.
        // Shows the closest few candidates and their scores so misfires can be diagnosed from real numbers.
        console.log(
            `[GestureRecognizer] strokes drawn: ${strokes.length}, ` +
            `enforceStrokeCount: ${this.enforceStrokeCount}, candidates compared: ${candidates.length}/${this.templates.length}`
        );
        console.log(
            '[GestureRecognizer] top matches:',
            allResults
                .sort((a, b) => a.distance - b.distance)
                .slice(0, 5)
                .map(r => `${r.name}: dist=${r.distance.toFixed(3)}, score=${Math.max((2.0 - r.distance) / 2.0, 0).toFixed(3)}`)
        );

        // Calculate a 0-1 score based on distance.
        // Max possible distance roughly 2.0. So score = (2 - distance) / 2
        const score = Math.max((2.0 - bestDistance) / 2.0, 0.0);

        // Per-gesture threshold adjustments — X is given extra leniency since diagonal wobble hurts its score.
        // Expressed as an offset from the base threshold (rather than an absolute value) so it still
        // tracks the live sensitivity setting instead of freezing at a stale hardcoded number.
        const GESTURE_THRESHOLD_OFFSETS: Record<string, number> = {
            'X': -0.10, // more lenient
        };
        const offset = GESTURE_THRESHOLD_OFFSETS[bestGesture] ?? 0;
        const MIN_THRESHOLD = 0.10; // floor so leniency offsets can never accept a near-zero/garbage match
        const threshold = Math.min(1, Math.max(MIN_THRESHOLD, this.threshold + offset));

        if (score < threshold) return null;
        return { gesture: bestGesture, score, centroid };
    }

    private normalize(strokes: Point[][]): StrokePoint[] {
        let points: StrokePoint[] = [];
        strokes.forEach((stroke, i) => {
            stroke.forEach(p => points.push({ x: p.x, y: p.y, id: i }));
        });

        points = this.resample(points, this.NUM_POINTS);
        points = this.scale(points);
        points = this.translateToOrigin(points);
        return points;
    }

    private resample(points: StrokePoint[], n: number): StrokePoint[] {
        if (points.length === 0) return [];

        const newPoints: StrokePoint[] = [{ ...points[0] }];
        const I = this.pathLength(points) / (n - 1);
        let D = 0.0;

        // Copy original array to avoid modifying it
        const pts = [...points];

        for (let i = 1; i < pts.length; i++) {
            if (pts[i].id === pts[i - 1].id) {
                const d = this.distance(pts[i - 1], pts[i]);
                if ((D + d) >= I && d !== 0) {
                    const qx = pts[i - 1].x + ((I - D) / d) * (pts[i].x - pts[i - 1].x);
                    const qy = pts[i - 1].y + ((I - D) / d) * (pts[i].y - pts[i - 1].y);
                    const q: StrokePoint = { x: qx, y: qy, id: pts[i].id };
                    newPoints.push(q);
                    pts.splice(i, 0, q); // insert q at position i
                    D = 0.0;
                } else {
                    D += d;
                }
            }
        }

        // Ensure we end up with exactly n points (sometimes precision errors cause n-1)
        while (newPoints.length < n) {
            newPoints.push({ ...pts[pts.length - 1] });
        }

        // Cap to exactly n in case precision issues caused more points
        return newPoints.slice(0, n);
    }

    private scale(points: StrokePoint[]): StrokePoint[] {
        let minX = Infinity, maxX = -Infinity;
        let minY = Infinity, maxY = -Infinity;

        for (const p of points) {
            minX = Math.min(minX, p.x);
            maxX = Math.max(maxX, p.x);
            minY = Math.min(minY, p.y);
            maxY = Math.max(maxY, p.y);
        }

        const size = Math.max(maxX - minX, maxY - minY);

        return points.map(p => ({
            x: size !== 0 ? (p.x - minX) / size : p.x - minX,
            y: size !== 0 ? (p.y - minY) / size : p.y - minY,
            id: p.id
        }));
    }

    private translateToOrigin(points: StrokePoint[]): StrokePoint[] {
        const centroid = this.calculateCentroid(points);
        return points.map(p => ({
            x: p.x - centroid.x,
            y: p.y - centroid.y,
            id: p.id
        }));
    }

    private calculateCentroid(points: Point[]): Point {
        if (points.length === 0) return { x: 0, y: 0 };
        let sumX = 0, sumY = 0;
        for (const p of points) {
            sumX += p.x;
            sumY += p.y;
        }
        return {
            x: sumX / points.length,
            y: sumY / points.length
        };
    }

    private pathLength(points: StrokePoint[]): number {
        let d = 0;
        for (let i = 1; i < points.length; i++) {
            if (points[i].id === points[i - 1].id) {
                d += this.distance(points[i - 1], points[i]);
            }
        }
        return d;
    }

    private distance(p1: Point, p2: Point): number {
        const dx = p2.x - p1.x;
        const dy = p2.y - p1.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    private greedyCloudMatch(pts1: StrokePoint[], pts2: StrokePoint[]): number {
        const e = 0.50; // step size factor
        const step = Math.max(1, Math.floor(Math.pow(pts1.length, 1.0 - e)));
        let min = Infinity;

        for (let i = 0; i < pts1.length; i += step) {
            const d1 = this.cloudDistance(pts1, pts2, i);
            const d2 = this.cloudDistance(pts2, pts1, i);
            min = Math.min(min, d1, d2);
        }
        return min;
    }

    private cloudDistance(pts1: StrokePoint[], pts2: StrokePoint[], start: number): number {
        const matched = new Array(pts1.length).fill(false);
        let sum = 0;
        let i = start;

        do {
            let index = -1;
            let min = Infinity;
            for (let j = 0; j < matched.length; j++) {
                if (!matched[j]) {
                    const d = this.distance(pts1[i], pts2[j]);
                    if (d < min) {
                        min = d;
                        index = j;
                    }
                }
            }
            if (index !== -1) {
                matched[index] = true;
                const weight = 1 - ((i - start + pts1.length) % pts1.length) / pts1.length;
                sum += weight * min;
            }
            i = (i + 1) % pts1.length;
        } while (i !== start);

        return sum;
    }
}

export class MinimapGestureOverlay {
    public canvas: HTMLCanvasElement;
    public ctx: CanvasRenderingContext2D;
    private isGestureModeActive: boolean = false;
    private resizeObserver: ResizeObserver;

    // Stroke capture state
    private strokes: Point[][] = [];
    private currentStroke: Point[] | null = null;
    private debounceTimer: number | null = null;

    // Rendering state
    private isFading: boolean = false;
    private fadeStartTime: number = 0;
    private currentInkColor: string = '#ffffff'; // default

    private readonly GESTURE_COLORS: Record<string, string> = {
        'X': '#f44336',         // Death (Red)
        'Checkmark': '#4caf50', // Kill (Green)
        'Circle': '#000000',    // Objective/Blank (Black)
        'Star': '#4caf50',      // Kill (Green)
        '!': '#2196f3',         // Util (Blue)
        '#': '#ff9800',         // Other (Amber/Yellow)
        'DoubleSlash': '#ff9800' // Other (Amber/Yellow) - alternate for '#'
    };

    constructor(
        private container: HTMLElement,
        private recognizer: GestureRecognizer,
        private onGestureComplete?: (result: { gesture: string, score: number, centroid: Point } | null) => void
    ) {
        this.canvas = document.createElement('canvas');
        this.canvas.classList.add('gesture-overlay-canvas');

        // Prevent default touch actions and intercept clicks so we don't trigger markers underneath
        this.canvas.style.touchAction = 'none';
        this.canvas.addEventListener('click', (e) => e.stopPropagation());

        // Ensure the container is positioned relatively so absolute canvas bounds to it
        const computedStyle = getComputedStyle(container);
        if (computedStyle.position === 'static') {
            container.style.position = 'relative';
        }

        container.appendChild(this.canvas);

        const context = this.canvas.getContext('2d');
        if (!context) throw new Error("Could not get 2D context for gesture overlay");
        this.ctx = context;

        // Setup resize observer
        this.resizeObserver = new ResizeObserver((entries) => {
            for (let entry of entries) {
                if (entry.target === this.container) {
                    this.resizeCanvas();
                }
            }
        });
        this.resizeObserver.observe(this.container);

        // Initial resize
        this.resizeCanvas();
        this.bindEvents();
    }

    private bindEvents() {
        this.canvas.addEventListener('pointerdown', this.onPointerDown);
        this.canvas.addEventListener('pointermove', this.onPointerMove);
        this.canvas.addEventListener('pointerup', this.onPointerUp);
        this.canvas.addEventListener('pointercancel', this.onPointerUp);
    }

    private unbindEvents() {
        this.canvas.removeEventListener('pointerdown', this.onPointerDown);
        this.canvas.removeEventListener('pointermove', this.onPointerMove);
        this.canvas.removeEventListener('pointerup', this.onPointerUp);
        this.canvas.removeEventListener('pointercancel', this.onPointerUp);
    }

    private onPointerDown = (e: PointerEvent) => {
        // Only accept primary button (left click / main touch contact / pen tip)
        if (!this.isGestureModeActive || e.button !== 0) return;

        // Suppress the follow-up 'mousedown' compat event the browser would otherwise fire for this
        // interaction. Without this, a left-click-drag both starts a gesture stroke here AND bubbles a
        // mousedown up to viewportEl's pan handler, causing the map to pan and draw at the same time.
        e.preventDefault();

        // Cancel fading if user starts drawing again quickly
        if (this.isFading) {
            this.isFading = false;
            this.strokes = [];
        }

        this.canvas.setPointerCapture(e.pointerId);

        if (this.debounceTimer !== null) {
            clearTimeout(this.debounceTimer);
            this.debounceTimer = null;
        }

        const pt = this.getPoint(e);
        this.currentStroke = [pt];
        this.strokes.push(this.currentStroke);
        this.currentInkColor = '#ffffff'; // reset to default color for new gesture

        this.renderLiveInk();
    };

    private onPointerMove = (e: PointerEvent) => {
        if (!this.isGestureModeActive || !this.currentStroke) return;

        this.currentStroke.push(this.getPoint(e));
        this.renderLiveInk();
    };

    private onPointerUp = (e: PointerEvent) => {
        if (!this.isGestureModeActive || !this.currentStroke) return;

        this.canvas.releasePointerCapture(e.pointerId);
        this.currentStroke = null;

        // Debounce to allow multi-stroke gestures (like 'X')
        this.debounceTimer = window.setTimeout(() => this.finalizeGesture(), 600);
    };

    private getPoint(e: PointerEvent): Point {
        const rect = this.canvas.getBoundingClientRect();
        // Scale from the live on-screen rect (which reflects any zoom transform) into the canvas's
        // actual internal buffer coordinates. Without this, ink drawn while zoomed lands at the wrong
        // spot because the buffer size and the rendered CSS size can diverge once a parent transform
        // is applied (CSS transforms don't trigger ResizeObserver, so the buffer can also go stale).
        const scaleX = this.canvas.width / rect.width;
        const scaleY = this.canvas.height / rect.height;
        return {
            x: (e.clientX - rect.left) * scaleX,
            y: (e.clientY - rect.top) * scaleY
        };
    }

    private finalizeGesture() {
        this.debounceTimer = null;
        if (this.strokes.length === 0) return;

        const result = this.recognizer.recognize(this.strokes);
        if (result) {
            // Update ink color based on recognized gesture
            this.currentInkColor = this.GESTURE_COLORS[result.gesture] || '#ffffff';
            this.renderLiveInk();

            if (this.onGestureComplete) {
                this.onGestureComplete(result);
            }
        } else {
            if (this.onGestureComplete) {
                this.onGestureComplete(null);
            }
        }

        // Start fade out animation before clearing
        this.isFading = true;
        this.fadeStartTime = performance.now();
        requestAnimationFrame(this.animateFadeOut);
    }

    private animateFadeOut = (time: number) => {
        if (!this.isFading) return;

        const elapsed = time - this.fadeStartTime;
        const duration = 200; // ms

        if (elapsed >= duration) {
            this.isFading = false;
            this.strokes = [];
            this.renderLiveInk(); // Will clear canvas since strokes is empty
        } else {
            const opacity = 1 - (elapsed / duration);
            this.renderLiveInk(opacity);
            requestAnimationFrame(this.animateFadeOut);
        }
    };

    private renderLiveInk(opacity: number = 1.0) {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        if (this.strokes.length === 0) return;

        this.ctx.save();
        this.ctx.globalAlpha = opacity;
        this.ctx.strokeStyle = this.currentInkColor;
        this.ctx.lineWidth = 4;
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';

        // Add a subtle drop-shadow for better visibility
        this.ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
        this.ctx.shadowBlur = 4;
        this.ctx.shadowOffsetX = 0;
        this.ctx.shadowOffsetY = 1;

        this.ctx.beginPath();
        for (const stroke of this.strokes) {
            if (stroke.length === 0) continue;
            this.ctx.moveTo(stroke[0].x, stroke[0].y);
            if (stroke.length < 3) {
                for (let i = 1; i < stroke.length; i++) {
                    this.ctx.lineTo(stroke[i].x, stroke[i].y);
                }
            } else {
                let i;
                for (i = 1; i < stroke.length - 2; i++) {
                    const xc = (stroke[i].x + stroke[i + 1].x) / 2;
                    const yc = (stroke[i].y + stroke[i + 1].y) / 2;
                    this.ctx.quadraticCurveTo(stroke[i].x, stroke[i].y, xc, yc);
                }
                // Curve through the last two points
                this.ctx.quadraticCurveTo(stroke[i].x, stroke[i].y, stroke[i + 1].x, stroke[i + 1].y);
            }
        }
        this.ctx.stroke();
        this.ctx.restore();
    }

    /** Force the canvas buffer to resync with its current rendered size. Call this after any
     *  transform-only size change (e.g. zoom), since CSS transforms never trigger ResizeObserver. */
    public refreshCanvasSize() {
        this.resizeCanvas();
    }

    private resizeCanvas() {
        const rect = this.container.getBoundingClientRect();
        // Set actual pixel dimensions to match display dimensions
        this.canvas.width = rect.width;
        this.canvas.height = rect.height;
        // Re-render in case resize happens while drawing or fading
        this.renderLiveInk(this.isFading ? undefined : 1.0);
    }

    public setGestureMode(active: boolean) {
        this.isGestureModeActive = active;
        if (active) {
            this.canvas.classList.add('is-gesture-mode');
        } else {
            this.canvas.classList.remove('is-gesture-mode');
            // If disabled while drawing/debouncing, immediately cancel and clear
            if (this.debounceTimer !== null) clearTimeout(this.debounceTimer);
            this.debounceTimer = null;
            this.strokes = [];
            this.currentStroke = null;
            this.isFading = false;
            this.renderLiveInk();
        }
    }

    public getIsGestureModeActive(): boolean {
        return this.isGestureModeActive;
    }

    public destroy() {
        this.unbindEvents();
        this.resizeObserver.disconnect();
        if (this.debounceTimer !== null) clearTimeout(this.debounceTimer);
        if (this.canvas.parentElement) {
            this.canvas.parentElement.removeChild(this.canvas);
        }
    }
}

export class GestureToggleButton {
    public button: HTMLButtonElement;
    private isActive: boolean = false;

    constructor(private wrapper: HTMLElement, private overlay: MinimapGestureOverlay) {
        this.button = document.createElement('button');
        this.button.classList.add('gesture-mode-toggle');
        this.button.title = "Toggle Gesture Mode";

        // Standard pen/pencil SVG icon
        this.button.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 20h9"></path>
                <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
            </svg>
        `;

        this.button.addEventListener('click', this.toggleMode);
        this.button.addEventListener('mousedown', (e) => e.stopPropagation());

        // Ensure wrapper has relative positioning to contain the absolute button
        const computedStyle = getComputedStyle(wrapper);
        if (computedStyle.position === 'static') {
            wrapper.style.position = 'relative';
        }

        wrapper.appendChild(this.button);
    }

    private toggleMode = (e: MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();

        this.isActive = !this.isActive;
        this.overlay.setGestureMode(this.isActive);

        if (this.isActive) {
            this.button.classList.add('is-active');
        } else {
            this.button.classList.remove('is-active');
        }
    };

    public destroy() {
        this.button.removeEventListener('click', this.toggleMode);
        if (this.button.parentElement) {
            this.button.parentElement.removeChild(this.button);
        }
    }
}
